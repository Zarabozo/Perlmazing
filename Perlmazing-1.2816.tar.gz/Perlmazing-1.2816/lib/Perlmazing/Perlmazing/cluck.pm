use Perlmazing;
use Carp ();

sub main {
	goto &Carp::cluck;
}

1;