use Perlmazing;

sub main ($) {
	_isa_ref('HASH', $_[0]);
}

