use Time::Precise ();

*main = \&Time::Precise::gmtime_hashref;