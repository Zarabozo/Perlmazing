use Perlmazing;

sub main ($) {
	_isa_ref('LVALUE', $_[0]);
}

