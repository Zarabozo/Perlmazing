use Perlmazing;

sub main ($) {
	_isa_ref('VSTRING', $_[0]);
}

