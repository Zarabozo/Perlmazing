use Perlmazing;

sub main ($) {
	not_empty($_[0]) ? 0 : 1;
}

