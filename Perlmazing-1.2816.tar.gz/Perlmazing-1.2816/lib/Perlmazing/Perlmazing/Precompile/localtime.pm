use Time::Precise 'localtime';

*main = \&localtime;