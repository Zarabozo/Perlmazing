use Perlmazing;

sub main ($) {
	_isa_ref('REF', $_[0]);
}

