use Perlmazing;

sub main ($) {
	_is_ref('GLOB', $_[0]);
}

