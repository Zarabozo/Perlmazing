use Perlmazing;

sub main ($) {
	_isa_ref('GLOB', $_[0]);
}

