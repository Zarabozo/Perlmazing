use Perlmazing;

sub main ($) {
	_isa_ref('IO', $_[0]);
}

