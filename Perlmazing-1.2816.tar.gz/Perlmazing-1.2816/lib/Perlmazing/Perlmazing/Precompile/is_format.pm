use Perlmazing;

sub main ($) {
	_is_ref('FORMAT', $_[0]);
}

