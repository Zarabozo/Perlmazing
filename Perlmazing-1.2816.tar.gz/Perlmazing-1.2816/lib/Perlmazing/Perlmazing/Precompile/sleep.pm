use Time::Precise 'sleep';

*main = \&sleep;