use Perlmazing;

sub main ($) {
	_is_ref('HASH', $_[0]);
}

