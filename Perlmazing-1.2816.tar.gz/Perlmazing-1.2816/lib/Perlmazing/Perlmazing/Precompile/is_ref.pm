use Perlmazing;

sub main ($) {
	_is_ref('REF', $_[0]);
}

