use Perlmazing;

sub main ($) {
	_isa_ref('ARRAY', $_[0]);
}

