use Time::Precise ();

*main = \&Time::Precise::timegm;