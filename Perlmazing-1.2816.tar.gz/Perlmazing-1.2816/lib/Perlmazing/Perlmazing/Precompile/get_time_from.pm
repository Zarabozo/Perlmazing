use Time::Precise ();

*main = \&Time::Precise::get_time_from;