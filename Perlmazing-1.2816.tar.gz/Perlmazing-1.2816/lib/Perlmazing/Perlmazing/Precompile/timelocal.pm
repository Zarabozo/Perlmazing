use Time::Precise ();

*main = \&Time::Precise::timelocal;