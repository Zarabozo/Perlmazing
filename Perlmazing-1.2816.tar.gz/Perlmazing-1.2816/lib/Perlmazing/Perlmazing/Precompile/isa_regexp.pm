use Perlmazing;

sub main ($) {
	_isa_ref('Regexp', $_[0]);
}

