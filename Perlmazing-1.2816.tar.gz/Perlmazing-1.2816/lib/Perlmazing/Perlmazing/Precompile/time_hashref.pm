use Time::Precise 'time_hashref';

*main = \&time_hashref;