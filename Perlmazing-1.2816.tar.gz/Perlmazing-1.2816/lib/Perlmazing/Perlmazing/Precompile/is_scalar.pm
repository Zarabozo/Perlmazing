use Perlmazing;

sub main ($) {
	_is_ref('SCALAR', $_[0]);
}

