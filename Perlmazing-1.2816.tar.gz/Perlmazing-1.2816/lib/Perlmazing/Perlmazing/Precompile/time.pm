use Time::Precise 'time';

*main = \&time;