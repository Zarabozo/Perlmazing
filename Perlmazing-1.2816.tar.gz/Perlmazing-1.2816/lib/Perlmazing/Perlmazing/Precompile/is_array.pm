use Perlmazing;

sub main ($) {
	_is_ref('ARRAY', $_[0]);
}

