use Perlmazing;
use Cwd ();

sub main {
	Cwd::cwd();
}

1;