use Scalar::Util 'unweaken';

sub main {
	unweaken $_[0];
}

1;
