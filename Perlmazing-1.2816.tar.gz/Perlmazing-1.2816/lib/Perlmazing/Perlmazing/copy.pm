use Perlmazing;
use File::Copy::Recursive 'rcopy';

*main = *rcopy;

1;
