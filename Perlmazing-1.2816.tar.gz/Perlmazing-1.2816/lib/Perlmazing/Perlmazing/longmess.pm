use Carp ();

sub main {
	goto &Carp::longmess;
}

1;