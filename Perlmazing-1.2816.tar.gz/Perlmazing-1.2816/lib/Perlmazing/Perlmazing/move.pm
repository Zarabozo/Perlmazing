use File::Copy::Recursive 'rmove';

*main = *rmove;

1;
